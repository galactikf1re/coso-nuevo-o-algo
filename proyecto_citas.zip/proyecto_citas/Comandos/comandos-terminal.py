"""
#1. env\Scripts\activate.bat
#2. python .\src\app.py



CREATE PROCEDURE sp_doctores_update (
	in p_id int(11),
	in p_nombre VARCHAR(100),
	in p_apellido VARCHAR(100),
    in p_cedula VARCHAR(50),
    in p_telefono VARCHAR(20),
    in p_correo VARCHAR(100),
    in p_id_especialidad INT(11)
)
BEGIN

END

"""