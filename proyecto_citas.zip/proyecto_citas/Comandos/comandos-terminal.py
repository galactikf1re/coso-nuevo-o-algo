"""
#1. env\Scripts\activate.bat
#2. python .\src\app.p

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_citas_post`(
	in p_id int (11),
    in p_id_paciente int(11),
	in p_id_doctor INT(11),
	in p_fecha DATE,
    in p_hora TIME, 
    in p_estado VARCHAR(20), 
    in p_motivo TEXT(100), 
    in p_precio_costo decimal(10,2) 
)
BEGIN
	declare flag_citas int default 0;
    select count(*) into flag_citas from citas where p_id_doctor = p_id;
    
    if flag_citas > 0 then
		insert into citas set
			fecha = p_fecha,
            hora = p_hora,
            estado = p_estado,
            motivo = p_motivo,
            precio_costo = p_precio_costo,
            id_paciente = p_id_paciente,
            id_doctor = p_id_doctor
           ;
		SELECT 'cita creada correctamente' as mensaje,1 as ok;
	else 
		select 'no se puede agendar la cita' as mensaje,0 as ok;
	end if;
END

"""