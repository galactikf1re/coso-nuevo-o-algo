"""
#1. env\Scripts\activate.bat
#2. python .\src\app.py


"""