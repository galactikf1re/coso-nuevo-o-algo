from app import app # IMPORTAR LA CARPETA APP 
#jsonify para hacer uso del metodo JSON
from flask import jsonify # type: ignore

@app.route("/usuarios", methods=["GET"])
def obtener_usuarios():
    # usuarios es un tipo de arreglo llamado DICCIONARIOS y esta convinado con una tupla. 
    # con esto enviamos (retornamos) un listado de usuarios
    return jsonify({"usuarios": ["Ana", "Luis", "Pedro"]})