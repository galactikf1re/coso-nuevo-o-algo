from app import app
from flask import jsonify

"""
@app.route con esta instrucción se crean las rutas (endpoints)
"""
@app.route("/", methods=["GET"])
def index():
    return jsonify({"mensaje": "Bienvenido a mi API"})
