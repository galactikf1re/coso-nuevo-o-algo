class DevelopmentConfig():
    DEBUG = True
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = "12345"
    MYSQL_DB = 'bd_consultorio_tpob'

config = {
    'development': DevelopmentConfig
}

