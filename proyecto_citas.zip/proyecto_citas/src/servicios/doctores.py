from flask import Blueprint, jsonify, request
from flask_mysqldb import MySQL

# Crear un Blueprint
doctores_bp = Blueprint('doctoress_bp', __name__)

# La conexión se pasa desde app.py
conexion = None  # Se inicializará desde app.py

@doctores_bp.route("/doctores", methods=["GET"]) #Endpoint
def lista_doctores():
    try:
        cursor = conexion.connection.cursor()
        #sql = "SELECT d.* , e.nombre as especialidad FROM doctores d INNER JOIN especialidades e ON d.id_especialidad = e.id_especialidad"
        cursor.execute(sql)
        datos = cursor.fetchall()
        
        columnas = [desc[0] for desc in cursor.description]
        arr_doctores = [dict(zip(columnas, fila)) for fila in datos]

        return jsonify({
            'datos': arr_doctores,
            'mensaje': "Listado de Pacientes"
        })
    except Exception as ex:
        return f"Error: {ex}"
    
@doctores_bp.route("/doctores/<nombre>", methods=["GET"]) #Endpoint
def buscar_doctores(nombre):
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM doctores WHERE nombre = '{0}'".format(nombre)
        cursor.execute(sql)
        datos = cursor.fetchone()
       
        if datos != None :
            doctor = {
                "id_doctor": datos[0],
                "nombre": datos[1],
                "apellido": datos[2],
                "cedula_profesional": datos[4],
                "telefono": datos[5],
                "correo": datos[6],
                "id_especialidad": datos[7]
            }

            return jsonify({
                'datos': doctor,
                'mensaje': "Doctor Encontrado"
            })
        else :
            return jsonify({'mensaje':'Doctor no encontrado'})
        
    except Exception as ex:
        return f"Error: {ex}"

@doctores_bp.route("/doctores", methods=["POST"]) #Endpoint
def crear_doctores():
  try:
      insert_datos = request.json #guardamos datos en un arrglo tipo diccionario
      print(insert_datos)
      cursor = conexion.connection.cursor()
      sql = f"""INSERT INTO doctores(id_paciente,nombre,apellido,fecha_nacimiento,sexo,telefono,correo,direccion,historial_medico,fecha_registro)
            VALUES ({insert_datos['nombre']})"""
      cursor.execute(sql)
      conexion.connection.commit()

      
      return jsonify({'mensaje' : 'registro creado'})  
  except Exception as ex:
        return f"Error: {ex}"