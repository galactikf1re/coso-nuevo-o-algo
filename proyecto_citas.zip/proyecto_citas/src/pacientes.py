
from flask import Blueprint, jsonify, request
from flask_mysqldb import MySQL

# Crear un Blueprint
pacientes_bp = Blueprint('pacientes_bp', __name__)

# La conexión se pasa desde app.py
conexion = None  # Se inicializará desde app.py

@pacientes_bp.route("/pacientes", methods=["GET"]) #Endpoint
def lista_pacientes():
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM pacientes"
        cursor.execute(sql)
        datos = cursor.fetchall()
        """
        unir 2 tuplas y crear en base a estas un arreglo de tipo diccionario (clave:valor)
        nombres = ('John', 'Jane', 'Alice') - clave
        edades = (20, 22, 25) - valor
        datos = zip(nombres,edades)
        zip(columnas, fila) empareja cada nombre de columna con su valor.
        dict - convierte esos pares en un diccionario.
        -----------------------------------------------------------------------
        """
        columnas = [desc[0] for desc in cursor.description]
        arr_pacientes = [dict(zip(columnas, fila)) for fila in datos]

        return jsonify({
            'datos': arr_pacientes,
            'mensaje': "Listado de Pacientes"
        })
    except Exception as ex:
        return f"Error: {ex}"
    
                    #URL                   #Metodo de transferencia
@pacientes_bp.route("/pacientes/<nombre>", methods=["GET"]) #Endpoint
def buscar_pacientes(nombre):
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM pacientes WHERE nombre = '{0}'".format(nombre)
        cursor.execute(sql)
        datos = cursor.fetchone()
       
        if datos != None :
            paciente = {
                "id_paciente": datos[0],
                "nombre": datos[1],
                "apellido": datos[2],
                "fecha_nacimiento": datos[3],
                "sexo": datos[4],
                "telefono": datos[5],
                "correo": datos[6],
                "direccion": datos[7],
                "historial_medico": datos[8],
                "fecha_registro": datos[9]
            }

            return jsonify({
                'datos': paciente,
                'mensaje': "Paciente Encontrado"
            })
        else :
            return jsonify({'mensaje':'Paciente no encontrado'})
        
    except Exception as ex:
        return f"Error: {ex}"

@pacientes_bp.route("/pacientes", methods=["POST"]) #Endpoint
def crear_pacientes():
  try:
      insert_datos = request.json #guardamos datos en un arrglo tipo diccionario
      print(insert_datos)
      cursor = conexion.connection.cursor()
      sql = f"""INSERT INTO pacientes(id_paciente,nombre,apellido,fecha_nacimiento,sexo,telefono,correo,direccion,historial_medico,fecha_registro)
            VALUES ({insert_datos['nombre']})"""
      cursor.execute(sql)
      conexion.connection.commit()

      
      return jsonify({'mensaje' : 'registro creado'})  
  except Exception as ex:
        return f"Error: {ex}"
  

  #Rogelio Centeno Sanchez, Leonardo Molina Flores