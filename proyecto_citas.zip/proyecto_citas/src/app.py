from flask import Flask
from flask_mysqldb import MySQL
from flask import jsonify # type: ignore


from config import config

from pacientes import pacientes_bp  
from Servicios.doctores import doctores_bp


app = Flask(__name__)

conexion = MySQL(app)

# Pasar la conexión al Blueprint
import pacientes
pacientes.conexion = conexion

import Servicios.doctores as doctores
doctores.conexion = conexion

# Registrar el Blueprint
app.register_blueprint(pacientes_bp)
app.register_blueprint(doctores_bp)



def pagina_no_encontrada(error):
    return "La página que intentas buscar no existe.."


if __name__ == '__main__':
    app.config.from_object(config['development']) #se carga desde un objeto from_object
    app.register_error_handler(404,pagina_no_encontrada)
    app.run()









