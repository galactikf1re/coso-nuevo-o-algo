from flask_mysqldb import MySQL
from flask import jsonify 
from flask import Blueprint
from flask import request
from config import config

from pacientes import pacientes_bp
from Servicios.doctores import doctores_bp 

conexion = None  
doctores_bp = Blueprint('doctores_bp', __name__)


@doctores_bp.route("/doctores", methods=["GET"]) #Endpoint
def lista_doctores():
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT d.* , e.nombre as especialidad FROM doctores d INNER JOIN especialidades e ON d.id_especialidad = e.id_especialidad"
        cursor.execute(sql)
        datos = cursor.fetchall()
        columnas = [desc[0] for desc in cursor.description]
        arr_doctores = [dict(zip(columnas, fila)) for fila in datos]

        return jsonify({
            'datos': arr_doctores,
            'mensaje': "Listado de Doctores"
        })
    except Exception as ex:
        return f"Error: {ex}"
    
                    #URL                   #Metodo de transferencia
@doctores_bp.route("/doctores/<nombre>", methods=["GET"]) #Endpoint
def buscar_doctores(id_doctor):
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM doctores WHERE id_doctor = '{0}'".format(id_doctor)
        cursor.execute(sql)
        datos = cursor.fetchone()
       
        if datos != None :
            doctor = {
                "id_doctor": datos[0],
                "nombre": datos[1],
                "apellido": datos[2],
                "cedula_profesional": datos[3],
                "telefono": datos[4],
                "correo": datos[5],
                "id_especialidad": datos[6],
            }

            return jsonify({
                'datos': doctor,
                'mensaje': "Doctor Encontrado"
            })
        else :
            return jsonify({'mensaje':'Doctor no encontrado'})
        
    except Exception as ex:
        return f"Error: {ex}"

@doctores_bp.route("/doctores", methods=["POST"]) #Endpoint
def crear_doctores():
  try:
      insert_datos = request.json #guardamos datos en un arrglo tipo diccionario
      print(insert_datos)
      cursor = conexion.connection.cursor()
      sql = f"""INSERT INTO doctores(id_doctores,nombre,apellido,cedula_profesional,telefono,correo,direccion,id_especialidad)
            VALUES ({insert_datos['nombre']})"""
      cursor.execute(sql)
      conexion.connection.commit()

      
      return jsonify({'mensaje' : 'registro creado'})  
  except Exception as ex:
        return f"Error: {ex}"