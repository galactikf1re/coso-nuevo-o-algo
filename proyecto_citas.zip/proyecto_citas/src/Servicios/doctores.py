from flask import Blueprint, jsonify, request
from flask_mysqldb import MySQL

doctores_bp = Blueprint('doctores_bp', __name__)

conexion = None

@doctores_bp.route("/doctores", methods=["GET"])
def lista_doctores():
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT d.*, e.nombre as especialidad FROM doctores d INNER JOIN especialidades e ON d.id_especialidad = e.id_especialidad"
        cursor.execute(sql)
        datos = cursor.fetchall()

        columnas = [desc[0] for desc in cursor.description]
        arr_doctores = [dict(zip(columnas, fila)) for fila in datos]

        return jsonify({
            'datos': arr_doctores,
            'mensaje': "Listado de Doctores"

        })
    except Exception as ex:
        return f"Error: {ex}"
    
@doctores_bp.route("/doctores/<id_doctor>", methods=["GET"])
def buscar_doctores(id_doctor):
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM doctores WHERE id_doctor = '{0}'".format(id_doctor)
        cursor.execute(sql)
        datos = cursor.fetchone()
       
        if datos != None :
            Doctores = {
                "id_doctor": datos[0],
                "nombre": datos[1],
                "apellido": datos[2],
                "especialidad": datos[3],
            }

            return jsonify({
                'datos': Doctores,
                'mensaje': "Doctores Encontrados"
            })
        else :
            return jsonify({'mensaje':'Doctor no encontrado'})
        
    except Exception as ex:
        return f"Error: {ex}"
        
@doctores_bp.route("/doctores", methods=["POST"])
def crear_doctores():
    try:
        insert_datos = request.json
        print(insert_datos)
        cursor = conexion.connection.cursor()
        sql = f"""INSERT INTO Doctores(nombre,apellido,especialidad)
               VALUES ('{insert_datos['nombre']}')"""
        cursor.execute(sql)
        conexion.connection.commit()
        return jsonify({'mensaje': "Doctor creado correctamente"})
    except Exception as ex:
            return f"Error: {ex}"

@doctores_bp.route("/doctores/<id_doctor>", methods=["DELETE"])
def delete_doctores(id_doctor):
    try:
        cursor = conexion.connection.cursor()
        sql = f"CALL sp_doctores_delete('{id_doctor}')"
        cursor.execute(sql)
        result = cursor.fetchone()
        cursor.nextset()
        conexion.connection.commit()
        cursor.close()
       
        return jsonify({'dat': result})
    except Exception as ex:
            return f"Error: {ex}"

@doctores_bp.route("/doctores", methods=["PUT"])
def update_doctores():
    try:
        update_datos = request.json
        cursor = conexion.connection.cursor()
        sql = f"""CALL sp_doctores_update('{update_datos['id_doctor']}',
            '{update_datos['nombre']}',
            '{update_datos['apellido']}',
            '{update_datos['cedula_profesional']}',
            '{update_datos['telefono']}',
            '{update_datos['correo']}',
            '{update_datos['id_especialidad']}')"""
        cursor.execute(sql)
        result = cursor.fetchone()
        cursor.nextset()
        conexion.connection.commit()
        cursor.close()
        return jsonify({'mensaje': result[0], 'ok': result[1]})
    except Exception as ex:
            return f"Error: {ex}"

