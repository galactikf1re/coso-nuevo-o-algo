from flask import Blueprint, jsonify, request
from flask_mysqldb import MySQL

citas_bp = Blueprint('citas_bp', __name__)
conexion = None

@citas_bp.route("/citas", methods=["POST"])
def crear_citas():
    try:
        insert_datos = request.json
        print(insert_datos)
        cursor = conexion.connection.cursor()
        sql = f"""INSERT INTO citas(id_paciente,id_doctor,fecha,hora,estado,motivo,precio_costo)
               VALUES ('{insert_datos['id_paciente','id_doctor','fecha','hora','estado','motivo','precio_costo']}')"""
        cursor.execute(sql)
        conexion.connection.commit()
        return jsonify({'mensaje': "Doctor creado correctamente"})
    except Exception as ex:
            return f"Error: {ex}"