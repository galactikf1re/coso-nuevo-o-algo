from flask import Blueprint, jsonify, request
from flask_mysqldb import MySQL

citas_bp = Blueprint('citas_bp', __name__)
conexion = None



@citas_bp.route("/citas",methods=["GET"])
def lista_citas():
     try:
            cursor = conexion.connection.cursor()
            sql = "select * FROM citas"
            cursor.execute(sql)
            datos = cursor.fetchall()

            columnas = [desc[0] for desc in cursor.description]
            arr_citas =[dict(zip(columnas,fila))for fila in datos]

            return jsonify({
                'datos':arr_citas,
                'mensaje' : "Listado de Citas"})
           
     except Exception as ex :
           return f"Error:{ex}"

@citas_bp.route("/citas", methods=["POST"])

def crear_citas():
    try:
        insert_datos = request.json
        cursor = conexion.connection.cursor()
        sql = f"""CALL sp_citas_post(
            '{insert_datos['id_cita']}',
            '{insert_datos['id_paciente']}',
            '{insert_datos['id_doctor']}', 
            '{insert_datos['fecha']}', 
            '{insert_datos['hora']}',
            '{insert_datos['estado']}',
            '{insert_datos['motivo']}',
            '{insert_datos['precio_costo']}',
            '{insert_datos['fecha_creacion']}'
        )"""
        cursor.execute(sql)
        result = cursor.fetchone()
        cursor.nextset()
        conexion.connection.commit()
        cursor.close()
        
        return jsonify({'mensaje': result[0],'ok': result[1]})
    except Exception as ex:
            return f"Error: {ex}"
