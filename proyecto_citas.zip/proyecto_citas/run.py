from app import app
#from flask import Flask # type: ignore
#from flask import jsonify

#app = Flask(__name__)


"""
@app.route('/')
def index():
    return "hola chicos"
"""   

if __name__ == '__main__':
    app.run(debug=True)